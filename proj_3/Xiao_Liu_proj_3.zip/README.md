# CSE-572-Data-Mining

1. I assume mealAmountData1-5 and mealData1-5 are under the same path of the train.py and test.py

2. If the path of the data doesn't fit, please modify the path.

3. Run train.py (will generate 3 pickle file) and then test.py.

4. The results are save as result.csv after runing test.py file. 